//Arithmetic operator program
import java.util.Scanner;
public class Operator{
	public static void main(String[] args) {
    	    Scanner a= new Scanner(System.in);
    	    System.out.println("Enter the First Number");
    	    int c=a.nextInt();
    	     System.out.println("Enter the Second Number");
    	     int d=a.nextInt();
	     System.out.println("c+d="+(c+d));
	     System.out.println("c-d="+(c-d));
	     System.out.println("c*d="+(c*d));
	     System.out.println("c/d="+(c/d));
	     System.out.println("c%d="+(c%d));
	}
}