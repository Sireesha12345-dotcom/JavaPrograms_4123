import java.util.*;
class Multiplication{
	public static void main(String[] args) {
		Scanner a =new Scanner(System.in);
		System.out.print("Enter the numbers:"+" ");
		int e =a.nextInt();
		for (int i=1;i<=10;i++){
		System.out.println(e+" x "+i+" = "+e*i);
		}
	}
}