import java.util.*;
class Countdown {
	public static void main(String[] args) {
		Scanner a =new Scanner(System.in);
		System.out.print("Enter the numbers:"+" ");
		int c=a.nextInt();
		for(int i=c;i>=1;i--){
		    System.out.println(i);
		}
	}
}