public class Parallelogram {
    public static void main(String[] args) {
        int n=3;
        for(int i=1;i<=3;i++){

            for(int s=1;s<=5-i;s++){
                System.out.print("  ");
            }

            for(int j=1;j<=(2*n-1);j++){
                System.out.print(7);
            }

            System.out.println();
        }
    }
}