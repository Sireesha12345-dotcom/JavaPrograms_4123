import java.util.*;
class Revmultiplication{
	public static void main(String[] args) {
		Scanner a =new Scanner(System.in);
		System.out.print("Enter the numbers:"+" ");
		int e =a.nextInt();
		int r=10;
		for (int i=r;i>=1;i--){
		System.out.println(e+" x "+i+" = "+e*i);
		}
	}
}