/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Datatypes
{
    public static void main (String[] args)
    {
        /* code */
        int i = 8;
        float f = 8.9999f;
        double d =1.4778969867;
        short s = 334;
        byte b =127;
        char ch='S';
        System.out.println(i);
        System.out.println(f);
        System.out.println(d);
        System.out.println(s);
        System.out.println(b);
        System.out.println(ch);
        
    }
}
