/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.io.*;
class Main{
    public static void main (String[] args) {
        /* code */
        for (int i=1;i<=3;i++){
            for(int j=1;j<=2;j++){
                System.out.print(i+" "+j+" ");
            }
        }
    }
}