/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// Encapsulation
import java.util.*;
class BankAccount{
    private double balance;
    
    public void deposit(double amount)
    {
        balance+=amount;
    }
    public void withdraw(double amount){
        if (amount<=balance){
            balance-=amount;
        }
        else{
            System.out.println("Insuffient Balance");
        }
    }
     public void checkBalance()
    {
        System.out.println("Current Balance: " + balance);
    }
    
    public void Exit(){
        System.out.println("Thank you for Banking");
    }
    public double getbalance(){
        return balance;
    }
}
public class Banking{
    public static void main (String[] args) {
        /* code */
        BankAccount ba=new BankAccount();
        ba.deposit(10000);
        ba.withdraw(5000);
        ba.checkBalance();
        ba.Exit();
    }
}