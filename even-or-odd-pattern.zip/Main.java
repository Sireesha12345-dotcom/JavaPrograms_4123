/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main {
    public static void main(String[] args) {

        int n = 2;

        for (int i = 1; i <= 3; i++) {

            for (int j = 1; j <= i; j++) {

                if (n % 2 == 0) {       
                    System.out.print(n+" ");
                }

                n = n + 2;
            }

            System.out.println();
        }
    }
}
/*if (n % 2 == 0) - Even printing , n starts with 2
if (n % 2 != 0) - Odd printing , n starts with 1 */