/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

public class Arraymatrix
{
    public static void main(String[] args)
    {
        int[][] a = {
            {2,3,4},
            {5,3,2},
            {7,6,4}
        };
        int[][] b={
            {2,3,4},
            {5,3,2},
            {7,6,4}
        };
        for(int i=0; i<3; i++)
        {
            for(int j=0; j<3; j++)
            {
                int c[i][j]=a[i][j]+b[i][j]
            }
            for(res:c[i][j])
            System.out.println(Array.toString(c));
        }
    }
}