/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;

class Mergereverse {
    public static void main(String[] args) {

        int a[] = {1, 3, 4};
        int b[] = {5, 6, 7, 8};

        int c[] = new int[a.length + b.length];

        int k = 0;

        // Add elements of b in reverse
        for (int i = b.length - 1; i >= 0; i--) {
            c[k++] = b[i];
        }

        // Add elements of a in reverse
        for (int i = a.length - 1; i >= 0; i--) {
            c[k++] = a[i];
        }

        System.out.println(Arrays.toString(c));
    }
}