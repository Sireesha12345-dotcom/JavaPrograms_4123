/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Pyramid
{
	public static void main(String[] args) {
		int n=4;
		//Rows
		for(int i=1;i<=n;i++){
		    //Spaces
		    for (int j=1;j<=n-i;j++)
		    {
		        System.out.print(" ");
		    }
		    //stars printing + columns
		    for (int k=1;k<=(2*i-1);k++)
		    {
		        System.out.print("*");
		    }
		    
		    
		    System.out.println();
		}
		//Rows
		for(int i=3;i>=1;i--){
		    //Spaces
		    for (int j=1;j<=n-i;j++)
		    {
		        System.out.print(" ");
		    }
		    //stars printing + columns
		    for (int k=1;k<=(2*i-1);k++)
		    {
		        System.out.print("*");
		    }
		    
		    
		    System.out.println();
		}
	}
}
