class Parent{
    public void print(){
        System.out.println("Java programming");
    }
}
class Child extends Parent{
    public void print_for(){
        System.out.println("Java is immutable");
    }
}
public class Main{
    public static void main(String args[]){
        Child ch= new Child();
        ch.print();
        ch.print_for();
    }
}