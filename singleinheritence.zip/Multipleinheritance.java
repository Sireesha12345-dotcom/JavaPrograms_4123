import java.util.*;
class Student{
    String name;
    String id;
    void Basicdetails(){
    System.out.println("Enter the Student details:");
}
}
class Details extends Student{
    void basic_details(){
        name="Sirisha";
        id="21341A0308";
        System.out.println("Name:"+name);
        System.out.println("ID:"+id);
    }
}
class Present extends Details{
    void Attendance(){
        Scanner sc =new Scanner (System.in);
        System.out.println("Student Attendance");
        int attendance=sc.nextInt();
        if (attendance>=75){
            System.out.println("Student eliglible for next year");
        }
        else{
            System.out.println("Not eligible");
        }
 }     
 }  
class Main{
    public static void main(String args[]){
        Present d= new Present();
        d.Basicdetails();
        d.basic_details();
        d.Attendance();
    }
}