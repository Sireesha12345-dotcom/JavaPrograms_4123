/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class MainSBB {
    public static void main(String[] args) {
        // 1. append()
        StringBuffer sb1 = new StringBuffer("Java");
        sb1.append(" Programming");
        System.out.println("append(): " + sb1);

        // 2. insert()
        StringBuffer sb2 = new StringBuffer("Java");
        sb2.insert(4, " Language");
        System.out.println("insert(): " + sb2);

        // 3. replace()
        StringBuffer sb3 = new StringBuffer("Java");
        sb3.replace(0, 4, "Python");
        System.out.println("replace(): " + sb3);

        // 4. delete()
        StringBuffer sb4 = new StringBuffer("Java Programming");
        sb4.delete(4, 16);
        System.out.println("delete(): " + sb4);

        // 5. deleteCharAt()
        StringBuffer sb5 = new StringBuffer("Java");
        sb5.deleteCharAt(1);
        System.out.println("deleteCharAt(): " + sb5);

        // 6. reverse()
        StringBuffer sb6 = new StringBuffer("Java");
        System.out.println("reverse(): " + sb6.reverse());

        // 7. length()
        StringBuffer sb7 = new StringBuffer("Java");
        System.out.println("length(): " + sb7.length());

        // 8. capacity()
        StringBuffer sb8 = new StringBuffer();
        System.out.println("capacity(): " + sb8.capacity());

        // 9. charAt()
        StringBuffer sb9 = new StringBuffer("Java");
        System.out.println("charAt(): " + sb9.charAt(1));

        // 10. setCharAt()
        StringBuffer sb10 = new StringBuffer("Java");
        sb10.setCharAt(0, 'K');
        System.out.println("setCharAt(): " + sb10);

        // 11. substring()
        StringBuffer sb11 = new StringBuffer("JavaProgramming");
        System.out.println("substring(): " + sb11.substring(4));

        // 12. indexOf()
        StringBuffer sb12 = new StringBuffer("Java");
        System.out.println("indexOf(): " + sb12.indexOf("a"));

        // 13. lastIndexOf()
        StringBuffer sb13 = new StringBuffer("Java");
        System.out.println("lastIndexOf(): " + sb13.lastIndexOf("a"));

        // 14. setLength()
        StringBuffer sb14 = new StringBuffer("Java");
        sb14.setLength(2);
        System.out.println("setLength(): " + sb14);

        // 15. toString()
        StringBuffer sb15 = new StringBuffer("Java");
        String str = sb15.toString();
        System.out.println("toString(): " + str);
    }
}

