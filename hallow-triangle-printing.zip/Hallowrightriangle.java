/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Hallowrightriangle
{
	public static void main(String[] args) {
		for (int i=1;i<=4;i++){   // reverse printing (int i=4;i>=1;i--)
		    for (int j=1;j<=i;j++){
		        if(i==1 || i==4 || j==1 || j==i){
		            System.out.print("*");
		        }
		        else{
		            System.out.print(" ");
		        }
		    }
		    System.out.println();
		}
	}
}
