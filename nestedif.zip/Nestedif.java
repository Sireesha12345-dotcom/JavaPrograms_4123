/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
class Nestedif
{
	public static void main(String[] args)
	{
		Scanner a = new Scanner(System.in);
		System.out.println("Enter the B Element");
		int b = a.nextInt();
		System.out.println("Enter the C Element");
		int c = a.nextInt();
		if (b<=20)
		{
		    if (c>=30)
		    {
		        System.out.println(b+c);
		    }
		    else{
		        System.out.println("c is wrong value");
		    }
		}
		else{
		    System.out.println("b is wrong element");
		}
	}
}
