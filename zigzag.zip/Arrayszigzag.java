/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class Arrayszigzag{
    public static void main (String[] args) {
        /* code */
        int a[]={1,3,4,5,6};
        int b[]={7,8,9,0,2};
        int c[]=new int[a.length+b.length];
        int k=0;
        for (int i=0;i<a.length;i++){
            c[k++]=a[i];
            c[k++]=b[i];
        }
        System.out.println("Zigzag="+Arrays.toString(c));
    }
}

