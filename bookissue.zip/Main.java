/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;

class Student
{
    int id;
    String name;
    int issuedBooks;

    void studentEntry()
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Student ID: ");
        id = sc.nextInt();

        sc.nextLine();

        System.out.print("Enter Student Name: ");
        name = sc.nextLine();

        System.out.println("Student Entered Successfully");
    }

    void issueBook()
    {
        if(issuedBooks >= 5)
        {
            System.out.println("Maximum Limit Reached");
            return;
        }

        issuedBooks++;
        System.out.println("Book Issued Successfully");
        System.out.println("Total Books Issued : " + issuedBooks);

        if(issuedBooks == 5)
        {
            System.out.println("Book Limit Reached");
        }
    }

    void viewDetails()
    {
        System.out.println("\nStudent Details");
        System.out.println("ID : " + id);
        System.out.println("Name : " + name);
        System.out.println("Books Issued : " + issuedBooks);
    }
}

public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        Student s = new Student();

        s.studentEntry();

        int choice;

        do
        {
            System.out.println("\n1. Issue Book");
            System.out.println("2. View Details");
            System.out.println("3. Exit");
            System.out.print("Enter Choice: ");

            choice = sc.nextInt();

            switch(choice)
            {
                case 1:
                    s.issueBook();
                    break;

                case 2:
                    s.viewDetails();
                    break;

                case 3:
                    System.out.println("Thank You");
                    break;

                default:
                    System.out.println("Invalid Choice");
            }

        } while(choice != 3);
    }
}