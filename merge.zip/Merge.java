/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class Merge
{
	public static void main(String[] args) {
		int a[]={93,83,82};
		
		int b[]={77,89,22,334,12};
		int c[]=new int[a.length+b.length];
		for(int i=0;i<a.length;i++){
		    c[i]=a[i];
	}
	for(int i=0;i<b.length;i++){
	    c[i+a.length]=b[i];
	}
	
	
	    System.out.println("Merge of the 2 arrays ="+' '+Arrays.toString(c));
	
}
}


