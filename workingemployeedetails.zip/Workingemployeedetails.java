/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Inheritance

class Employee
{
    void work(String name)
    {
        System.out.println(name+"Employee is Working");
    }
}

class Developer extends Employee
{
    void code()
    {
        System.out.println("Developer writes the Code");
    }
}

public class Workingemployeedetails
{
    public static void main (String[] args) 
    {
        Developer d = new Developer();
        d.work("Sirisha ");
        d.code();
    }
}