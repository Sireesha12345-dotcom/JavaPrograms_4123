/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Electric
{
	public static void main(String[] args)
	{
		Scanner a = new Scanner(System.in);
		System.out.println("Enter the Bill Units:");
		int units = a.nextInt();
		int charges= units;
		if(units<=100){
		    charges= 50;
		}
		else if (units >=100 && units <=200)
		{
		    charges = 50+ (units - 100)*2;
		}
		else if (units>200)
		{
		    charges= 50+100*2+(units- 200)*5;
		}
		System.out.println("Total Bill:"+charges);
	}
}
