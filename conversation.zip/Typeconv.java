/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class Typeconv
{
	public static void main(String[] args) {
		int a=8;
	    double d=a;
	    short s=988;
        double e=s;
	    System.out.println(a);
	    System.out.println(d);
	    System.out.println(s);
	    System.out.println(e);
	}
}
