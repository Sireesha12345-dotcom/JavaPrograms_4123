import java.util.*;
class Short1{
    public static void main (String[] args) {
        /* code */
        short s=988;
        double e=s;
        System.out.println(s);
        System.out.println(e);
    }
}