/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.Scanner;

public class Lcm_of_numbers {
	public static void main(String args[]) {
		Scanner sc =new Scanner (System.in);
		System.out.println("Enter the first number:");
		int a=sc.nextInt();
		System.out.println("Enter the second number:");
		int b=sc.nextInt();
		int max = (a>b)?a:b;
		while(true) {
			if (max % a==0 && max % b==0) {
				System.out.println("LCM:"+max);
				break;
			}
			max++;
		}
		sc.close();
	}
}