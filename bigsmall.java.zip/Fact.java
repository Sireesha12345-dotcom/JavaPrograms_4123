import java.util.*;

class Fact
{
    public static void main(String[] args)
    {
        Scanner a = new Scanner(System.in);
        System.out.println("Enter the Number:");
        int f = a.nextInt();
        int fact = 1;
        for(int i = 1; i <= f; i++)
        {
            fact = fact * i;
        }
        System.out.println("Factorial: " + fact);
    }
}