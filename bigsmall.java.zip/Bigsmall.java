/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class Bigsmall
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        // enter array size
        System.out.println("Enter the size");
        int n = sc.nextInt();
        int arr[]=new int[n];
        // array elements
        System.out.println("Enter the elements");
        for (int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        int greatest = arr[0];
        int smallest = arr[0];
        for (int i= 1; i<n; i++)
        {
            if (arr[i]>greatest)
            {
                greatest=arr[i];
            }
            if (arr[i]<smallest){
                smallest=arr[i];
            }
        }
        System.out.println("Greatest:"+greatest);
        System.out.println("Smallest:"+smallest);
        sc.close();
    }
}